"use client";

import { useCallback, useState } from "react";
import { CldImage } from "next-cloudinary";

interface UploadResult {
  secure_url: string;
  public_id: string;
  width: number;
  height: number;
}

interface Props {
  /** Called with the secure_url string(s) after a successful upload */
  onUpload: (urls: string[]) => void;
  /** Allow multiple file selection. Default: false */
  multiple?: boolean;
  /** Already-saved image URLs to preview (e.g. when editing a product) */
  existingUrls?: string[];
  folder?: string;
}

export default function CloudinaryUpload({
  onUpload,
  multiple = false,
  existingUrls = [],
  folder,
}: Props) {
  const [previews, setPreviews] = useState<string[]>(existingUrls);
  const [uploading, setUploading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const handleFiles = useCallback(
    async (e: React.ChangeEvent<HTMLInputElement>) => {
      const files = Array.from(e.target.files ?? []);
      if (!files.length) return;

      setUploading(true);
      setError(null);

      try {
        // Fetch signature from our protected API route
        const sigRes = await fetch(
          `/api/admin/cloudinary/signature${folder ? `?folder=${folder}` : ""}`
        );
        if (!sigRes.ok) throw new Error("Failed to get upload signature");
        const { timestamp, signature, apiKey, cloudName, folder: uploadFolder } =
          await sigRes.json();

        const uploaded: string[] = [];

        for (const file of files) {
          const formData = new FormData();
          formData.append("file", file);
          formData.append("api_key", apiKey);
          formData.append("timestamp", String(timestamp));
          formData.append("signature", signature);
          formData.append("folder", uploadFolder);

          const res = await fetch(
            `https://api.cloudinary.com/v1_1/${cloudName}/image/upload`,
            { method: "POST", body: formData }
          );

          if (!res.ok) throw new Error("Upload failed for " + file.name);
          const data: UploadResult = await res.json();
          uploaded.push(data.secure_url);
        }

        setPreviews((prev) => [...prev, ...uploaded]);
        onUpload(uploaded);
      } catch (err) {
        setError(err instanceof Error ? err.message : "Upload failed");
      } finally {
        setUploading(false);
      }
    },
    [folder, onUpload]
  );

  const removePreview = (url: string) => {
    setPreviews((prev) => prev.filter((u) => u !== url));
  };

  return (
    <div className="space-y-3">
      {previews.length > 0 && (
        <div className="flex flex-wrap gap-3">
          {previews.map((url) => (
            <div
              key={url}
              className="relative w-24 h-24 rounded-lg overflow-hidden border border-border group"
            >
              <CldImage
                src={url}
                fill
                alt="Product image"
                className="object-cover"
                sizes="96px"
              />
              <button
                type="button"
                onClick={() => removePreview(url)}
                className="absolute inset-0 bg-black/50 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center text-white text-xs"
              >
                Remove
              </button>
            </div>
          ))}
        </div>
      )}

      <label className="flex flex-col items-center justify-center w-full h-32 border-2 border-dashed border-medical-green/40 rounded-lg cursor-pointer hover:border-medical-green hover:bg-medical-greenPale/30 transition-colors">
        <div className="flex flex-col items-center gap-1 text-sm text-muted-foreground">
          {uploading ? (
            <span className="text-medical-green animate-pulse">Uploading…</span>
          ) : (
            <>
              <span className="font-medium text-medical-green">Click to upload</span>
              <span>PNG, JPG, WebP up to 10 MB</span>
            </>
          )}
        </div>
        <input
          type="file"
          className="sr-only"
          accept="image/*"
          multiple={multiple}
          disabled={uploading}
          onChange={handleFiles}
        />
      </label>

      {error && <p className="text-sm text-destructive">{error}</p>}
    </div>
  );
}
