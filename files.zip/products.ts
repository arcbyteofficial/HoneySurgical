"use server";

import { revalidatePath } from "next/cache";
import { createClient } from "@/lib/supabase/server";

// ─── READ ──────────────────────────────────────────────────────────────────

export async function getProducts({
  search,
  categoryId,
  page = 1,
  pageSize = 24,
}: {
  search?: string;
  categoryId?: string;
  page?: number;
  pageSize?: number;
} = {}) {
  const supabase = await createClient();
  const from = (page - 1) * pageSize;
  const to = from + pageSize - 1;

  let query = supabase
    .from("products")
    .select("*, categories(name, slug)", { count: "exact" })
    .eq("is_active", true)
    .order("name")
    .range(from, to);

  if (search) {
    query = query.textSearch("fts", search, { type: "websearch" });
  }
  if (categoryId) {
    query = query.eq("category_id", categoryId);
  }

  const { data, error, count } = await query;
  if (error) throw error;
  return { products: data ?? [], total: count ?? 0 };
}

export async function getProductBySlug(slug: string) {
  const supabase = await createClient();
  const { data, error } = await supabase
    .from("products")
    .select("*, categories(name, slug)")
    .eq("slug", slug)
    .single();

  if (error) throw error;
  return data;
}

// ─── WRITE (admin-only) ────────────────────────────────────────────────────

export async function createProduct(payload: {
  name: string;
  slug: string;
  description?: string;
  category_id?: string;
  images?: string[];        // Cloudinary secure_url array
  sku?: string;
  is_active?: boolean;
}) {
  const supabase = await createClient();
  const { data, error } = await supabase
    .from("products")
    .insert(payload)
    .select()
    .single();

  if (error) throw error;
  revalidatePath("/products");
  revalidatePath("/admin/products");
  return data;
}

export async function updateProduct(
  id: string,
  payload: Partial<{
    name: string;
    slug: string;
    description: string;
    category_id: string;
    images: string[];
    sku: string;
    is_active: boolean;
  }>
) {
  const supabase = await createClient();
  const { data, error } = await supabase
    .from("products")
    .update(payload)
    .eq("id", id)
    .select()
    .single();

  if (error) throw error;
  revalidatePath("/products");
  revalidatePath(`/products/${payload.slug}`);
  revalidatePath("/admin/products");
  return data;
}

export async function deleteProduct(id: string) {
  const supabase = await createClient();
  const { error } = await supabase.from("products").delete().eq("id", id);
  if (error) throw error;
  revalidatePath("/products");
  revalidatePath("/admin/products");
}
