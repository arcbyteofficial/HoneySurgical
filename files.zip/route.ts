import { NextResponse } from "next/server";
import { createClient } from "@/lib/supabase/server";
import { generateUploadSignature, UPLOAD_FOLDER } from "@/lib/cloudinary";

/**
 * GET /api/admin/cloudinary/signature
 *
 * Returns a signed Cloudinary upload payload.
 * Protected: only authenticated admin users may call this.
 */
export async function GET(request: Request) {
  // Auth guard
  const supabase = await createClient();
  const {
    data: { user },
  } = await supabase.auth.getUser();

  if (!user) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }

  // Optional: pass ?folder=custom-folder via query string
  const { searchParams } = new URL(request.url);
  const folder = searchParams.get("folder") ?? UPLOAD_FOLDER;

  const payload = generateUploadSignature(folder);
  return NextResponse.json(payload);
}
