/**
 * Database type definitions for Honey Surgicals.
 * Replace this with `supabase gen types typescript` output once the DB is provisioned.
 */

export type Json =
  | string
  | number
  | boolean
  | null
  | { [key: string]: Json | undefined }
  | Json[];

export interface Database {
  public: {
    Tables: {
      categories: {
        Row: {
          id: string;
          name: string;
          slug: string;
          description: string | null;
          parent_id: string | null;
          image_url: string | null;
          sort_order: number;
          created_at: string;
          updated_at: string;
        };
        Insert: Omit<Database["public"]["Tables"]["categories"]["Row"], "id" | "created_at" | "updated_at">;
        Update: Partial<Database["public"]["Tables"]["categories"]["Insert"]>;
      };
      products: {
        Row: {
          id: string;
          name: string;
          slug: string;
          description: string | null;
          category_id: string | null;
          images: string[];
          sku: string | null;
          is_active: boolean;
          fts: unknown | null;
          created_at: string;
          updated_at: string;
        };
        Insert: Omit<Database["public"]["Tables"]["products"]["Row"], "id" | "fts" | "created_at" | "updated_at">;
        Update: Partial<Database["public"]["Tables"]["products"]["Insert"]>;
      };
      inquiries: {
        Row: {
          id: string;
          product_id: string | null;
          product_ids: string[] | null;
          name: string;
          company: string | null;
          email: string;
          phone: string | null;
          message: string;
          status: "new" | "read" | "replied" | "closed";
          created_at: string;
          updated_at: string;
        };
        Insert: Omit<Database["public"]["Tables"]["inquiries"]["Row"], "id" | "status" | "created_at" | "updated_at">;
        Update: Partial<Database["public"]["Tables"]["inquiries"]["Insert"]> & {
          status?: Database["public"]["Tables"]["inquiries"]["Row"]["status"];
        };
      };
    };
    Views: Record<string, never>;
    Functions: Record<string, never>;
    Enums: Record<string, never>;
  };
}

export type Category = Database["public"]["Tables"]["categories"]["Row"];
export type Product  = Database["public"]["Tables"]["products"]["Row"];
export type Inquiry  = Database["public"]["Tables"]["inquiries"]["Row"];
