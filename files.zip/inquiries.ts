"use server";

import { revalidatePath } from "next/cache";
import { createClient } from "@/lib/supabase/server";

export async function submitInquiry(payload: {
  product_id?: string;
  name: string;
  company?: string;
  email: string;
  phone?: string;
  message: string;
  product_ids?: string[];   // for multi-product / compare inquiries
}) {
  const supabase = await createClient();
  const { data, error } = await supabase
    .from("inquiries")
    .insert(payload)
    .select()
    .single();

  if (error) throw error;
  revalidatePath("/admin/inquiries");
  return data;
}

export async function getInquiries({
  status,
  page = 1,
  pageSize = 20,
}: { status?: string; page?: number; pageSize?: number } = {}) {
  const supabase = await createClient();
  const from = (page - 1) * pageSize;
  const to = from + pageSize - 1;

  let query = supabase
    .from("inquiries")
    .select("*, products(name, slug)", { count: "exact" })
    .order("created_at", { ascending: false })
    .range(from, to);

  if (status) query = query.eq("status", status);

  const { data, error, count } = await query;
  if (error) throw error;
  return { inquiries: data ?? [], total: count ?? 0 };
}

export async function updateInquiryStatus(
  id: string,
  status: "new" | "read" | "replied" | "closed"
) {
  const supabase = await createClient();
  const { error } = await supabase
    .from("inquiries")
    .update({ status })
    .eq("id", id);

  if (error) throw error;
  revalidatePath("/admin/inquiries");
}
