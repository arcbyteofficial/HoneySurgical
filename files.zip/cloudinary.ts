import { v2 as cloudinary } from "cloudinary";

cloudinary.config({
  cloud_name: process.env.CLOUDINARY_CLOUD_NAME,
  api_key:    process.env.CLOUDINARY_API_KEY,
  api_secret: process.env.CLOUDINARY_API_SECRET,
  secure:     true,
});

export default cloudinary;

/** Default folder for all product images */
export const UPLOAD_FOLDER =
  process.env.CLOUDINARY_UPLOAD_FOLDER ?? "honey-surgicals/products";

/**
 * Build a signed upload payload for the browser to POST directly to Cloudinary.
 * Called from the /api/admin/cloudinary/signature route — never from the client.
 */
export function generateUploadSignature(folder = UPLOAD_FOLDER) {
  const timestamp = Math.round(Date.now() / 1000);
  const params = { timestamp, folder };

  const signature = cloudinary.utils.api_sign_request(
    params,
    process.env.CLOUDINARY_API_SECRET!
  );

  return {
    timestamp,
    signature,
    folder,
    apiKey: process.env.CLOUDINARY_API_KEY!,
    cloudName: process.env.CLOUDINARY_CLOUD_NAME!,
  };
}
